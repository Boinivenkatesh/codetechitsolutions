/**
 * 
 */
/**
 * @author Bichoy Emad
 *
 */
module TicTacToe {
	requires java.desktop;
}